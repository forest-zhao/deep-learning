import matplotlib.image as mpimg # mpimg 用于读取图片
import numpy as np
train_featureset=[]
train_labelset=[]
with open("dataset/train.txt") as f:
      for line in f.readlines():
          x=line.strip().split()
          filename=x[0]
          feature=mpimg.imread('dataset/train-set/' + filename)
          label=int(x[1])

          train_featureset.append(feature)
          train_labelset.append(label)

X_train=np.array(train_featureset)
y_train=np.array(train_labelset)

print(X_train.shape)

test_featureset=[]
test_labelset=[]
with open("dataset/vali.txt") as f:
      for line in f.readlines():
          x=line.strip().split()
          filename=x[0]
          feature=mpimg.imread('dataset/vali-set/' + filename)
          label=int(x[1])
          test_featureset.append(feature)
          test_labelset.append(label)

X_test=np.array(test_featureset)
y_test=np.array(test_labelset)

print(X_test)

