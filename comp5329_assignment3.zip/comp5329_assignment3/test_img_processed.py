import numpy as np
from PIL import Image
import PIL.ImageOps
import cv2
import math
from scipy import ndimage
import time


def getBestShift(img):
    cy,cx = ndimage.measurements.center_of_mass(img)

    rows,cols = img.shape
    shiftx = np.round(cols/2.0-cx).astype(int)
    shifty = np.round(rows/2.0-cy).astype(int)

    return shiftx,shifty


def shift(img,sx,sy):
    rows,cols = img.shape
    M = np.float32([[1,0,sx],[0,1,sy]])
    shifted = cv2.warpAffine(img,M,(cols,rows))
    return shifted


#######    Step 1: Loading data  ###########
file2 = open('dataset/vali.txt')
val_list2 = file2.readlines()
image_list2=[]
label_lists2 = []
for string in val_list2:
    string = string.split(' ')
    image_list2.append(string[0])
    label_lists2.append(int(string[1].strip()))
a2=np.asarray(label_lists2)
n_values2 = np.max(a2) + 1
test_labels=np.eye(n_values2)[a2]
test_string_images=np.array(image_list2)






print(len(test_string_images))
images = np.zeros(( test_string_images.shape[0], 1024))
train_list=[]
start_time = time.time()
for j in range(len(test_string_images)):
    print('the', j, 'th image', test_string_images[j])
    #image = Image.open('data/Assignment-2-Dataset-Round-1/train-set/'+ train_string_images[j])
    gray = cv2.imread('dataset/vali-set/'+ test_string_images[j], cv2.IMREAD_GRAYSCALE)
    #cv2.imshow("ori", gray)
    gray = cv2.resize(255-gray, (32, 32))

    #(thresh, gray) = cv2.threshold(gray, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

    while np.sum(gray[0]) == 0:
        gray = gray[1:]

    while np.sum(gray[:, 0]) == 0:
        gray = np.delete(gray, 0, 1)

    while np.sum(gray[-1]) == 0:
        gray = gray[:-1]

    while np.sum(gray[:, -1]) == 0:
        gray = np.delete(gray, -1, 1)

    rows, cols = gray.shape

    if rows > cols:
        factor = 26.0 / rows
        rows = 26
        cols = int(round(cols * factor))
        # first cols than rows
        gray = cv2.resize(gray, (cols, rows))
    else:
        factor = 26.0 / cols
        cols = 26
        rows = int(round(rows * factor))
        # first cols than rows
        gray = cv2.resize(gray, (cols, rows))

    colsPadding = (int(math.ceil((32 - cols) / 2.0)), int(math.floor((32 - cols) / 2.0)))
    rowsPadding = (int(math.ceil((32 - rows) / 2.0)), int(math.floor((32 - rows) / 2.0)))
    gray = np.lib.pad(gray, (rowsPadding, colsPadding), 'constant')

    shiftx, shifty = getBestShift(gray)
    shifted = shift(gray, shiftx, shifty)
    gray = shifted

    # save the processed images
    cv2.imwrite('processeed_test_32/'+ test_string_images[j], gray)
end_time = time.time()
print('duration = ', end_time-start_time)
    #flatten = gray.flatten() / 255.0
    #images[j] = flatten
    #cv2.imshow("sda",gray)
    #cv2.imshow("sdqq", images[j])
    #cv2.waitKey(0)
#train_images=np.concatenate(train_list)
