file="valitest.txt"
with open(file,"w") as f:
    with open("dataset/train.txt") as ff:
        for line in ff.readlines():
             tmp=line.split()
             name=tmp[1]
