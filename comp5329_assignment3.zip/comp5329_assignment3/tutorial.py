
import tensorflow as tf


tf.__version__


#######    Step 1: Loading data¶  ###########
from tensorflow.examples.tutorials.mnist import input_data
data = input_data.read_data_sets('minist/', one_hot=True)
print('train_images', data.train.images[100])
print('train_labels', data.train.labels)

print("Size of:")
print("- Training-set:\t\t{}".format(len(data.train.labels)))
print("- Test-set:\t\t{}".format(len(data.test.labels)))
print("- Validation-set:\t{}".format(len(data.validation.labels)))





