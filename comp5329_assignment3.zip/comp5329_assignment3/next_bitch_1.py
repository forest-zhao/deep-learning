import numpy as np
from PIL import Image
import PIL.ImageOps


class DataSet(object):


  def __init__(self,images,labels):
    self._num_examples = images.shape[0]
    self._images = images
    self._labels = labels
    self._epochs_completed = 0
    self._index_in_epoch = 0
    #print('self.images', images)

  def images(self):
    return self._images


  def labels(self):
    return self._labels


  def num_examples(self):
    return self._num_examples

  def epochs_completed(self):
    return self._epochs_completed


  def next_batch(self,images,labels,batch_size,shuffle=True):

    start = self._index_in_epoch
    # Shuffle for the first epoch
    if self._epochs_completed == 0 and start == 0 and shuffle:
      perm0 = np.arange(self._num_examples)
      np.random.shuffle(perm0)
      #print('perm0', perm0)

      self._images = images[perm0]
      self._labels = labels[perm0]
    # Go to the next epoch
    if start + batch_size > self._num_examples:
      # Finished epoch
      self._epochs_completed += 1
      # Get the rest examples in this epoch
      rest_num_examples = self._num_examples - start
      images_rest_part = self._images[start:self._num_examples]
      labels_rest_part = self._labels[start:self._num_examples]
      # Shuffle the data
      if shuffle:
        perm = np.arange(self._num_examples)
        np.random.shuffle(perm)
        self._images = images[perm]
        self._labels = labels[perm]
      # Start next epoch
      start = 0
      self._index_in_epoch = batch_size - rest_num_examples
      end = self._index_in_epoch
      images_new_part = self._images[start:end]
      labels_new_part = self._labels[start:end]
      return np.concatenate(
          (images_rest_part, images_new_part), axis=0), np.concatenate(
              (labels_rest_part, labels_new_part), axis=0)
    else:
      self._index_in_epoch += batch_size
      end = self._index_in_epoch
      return self._images[start:end], self._labels[start:end]



''''

file1 = open('train.txt')
val_list1 = file1.readlines()
image_list1=[]
label_lists1 = []
for string in val_list1:
    string = string.split(' ')
    image_list1.append(string[0])
    label_lists1.append(int(string[1].strip()))
a1=np.array(label_lists1)
n_values1 = np.max(a1) + 1
train_labels=np.eye(n_values1)[a1]
train_string_images=np.array(image_list1)


train_list=[]
for j in range(len(train_string_images)):
    image = Image.open('train-set/'+ train_string_images[j])
    image_raw_data = np.array(PIL.ImageOps.invert(image))
    new_result = image_raw_data.reshape(1, 16384)  # 转化成 （1，16384）   128*128=16384
    train_result = np.multiply(new_result, 1.0 / 255.0)
    #test_result=test.tolist()
    train_list.append(train_result)
    print(j)
train_images=np.concatenate(train_list)
'''

#x_true,y_true_labels=DataSet(train_images,train_labels).next_batch(train_images,train_labels,batch_size=64)
#print('x_true',x_true)
#print('y_true_labels', y_true_labels)