import numpy
import matplotlib.image as mpimg
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import Flatten
from keras.layers.convolutional import Conv2D
from keras.layers.convolutional import MaxPooling2D
from keras.utils import np_utils
from keras import backend as K
K.set_image_dim_ordering('th')


numpy.random.seed(9)
train_featureset=[]
train_labelset=[]
with open("dataset/train.txt") as f:
      for line in f.readlines():
          x=line.strip().split()
          filename=x[0]
          feature=mpimg.imread('dataset/train-set/' + filename)
          label=int(x[1])

          train_featureset.append(feature)
          train_labelset.append(label)

train_featureset=numpy.array(train_featureset)
train_labelset=numpy.array(train_labelset)



test_featureset=[]
test_labelset=[]
with open("dataset/vali.txt") as f:
      for line in f.readlines():
          x=line.strip().split()
          filename=x[0]
          feature=mpimg.imread('dataset/vali-set/' + filename)
          label=int(x[1])
          test_featureset.append(feature)
          test_labelset.append(label)

valiset=numpy.array(test_featureset)
valilabel=numpy.array(test_labelset)
# [samples][pixels][width][height]
train_featureset = train_featureset.reshape(train_featureset.shape[0], 1, 128, 128).astype('float32')
valiset = valiset.reshape(valiset.shape[0], 1, 128, 128).astype('float32')
# normalize
train_featureset = train_featureset / 255
valiset = valiset / 255

train_labelset = np_utils.to_categorical(train_labelset)
valilabel = np_utils.to_categorical(valilabel)

def CNN_model():
	model = Sequential()
	model.add(Conv2D(64, (5, 5), input_shape=(1, 128, 128), activation='relu'))
	model.add(MaxPooling2D(pool_size=(4, 4)))
	model.add(Conv2D(16, (3, 3), activation='relu'))
	model.add(MaxPooling2D(pool_size=(2, 2)))
	model.add(Dropout(0.5))
	model.add(Flatten())
	model.add(Dense(128, activation='relu'))
	model.add(Dense(70, activation='relu'))
	model.add(Dense(valilabel.shape[1], activation='softmax'))
	# Compile
	model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
	return model

# build
model = CNN_model()
# Fit
model.fit(train_featureset, train_labelset, validation_data=(valiset, valilabel), epochs=1, batch_size=2000)

marks = model.evaluate(valiset, valilabel, verbose=0)
print("CNN Error: %.2f%%" % (100-marks[1]*100))