import numpy as np
from activation import *
class HiddenLayer(object):
    def __init__(self, n_in, n_out, W=None, b=None,
                 activation='relu', num_layer=1):

        self.input = None
        self.activation = Activation(activation).f
        self.activation_deriv = Activation(activation).f_deriv
        # end-snippet-1

        self.v_w = 0
        self.v_b = 0

        self.num_layer = num_layer
        self.cache = {}
        self.cache['cache' + np.str(num_layer)] = None

        self.W = np.random.uniform(
            low=-np.sqrt(6 / (n_in + n_out)),
            high=np.sqrt(6 / (n_in + n_out)),
            size=(n_in, n_out)
        )

        self.b = np.zeros(n_out, )

        self.grad_W = np.zeros(self.W.shape)
        self.grad_b = np.zeros(self.b.shape)

    def dropout_forward(self, x, dropout_param):

        # Get the current dropout mode, p, seed
        p, mode = dropout_param['p'], dropout_param['mode']
        if 'seed' in dropout_param:
            np.random.seed(dropout_param['seed'])

        # Initialization of outputs and mask

        mask = None
        out = x

        if mode == 'train':
            # Create an apply mask (normally p=0.5 for half of neurons), we scale all
            # by p to void having to multiply by p on backpropagation, this is called inverted dropout
            mask = (np.random.rand(*x.shape) < p) / p
            out = x * mask
            # print('mask.shape', mask.shape)
        elif mode == 'test':
            # During prediction no mask is used
            mask = None
            out = x
        # Save mask and dropout parameters for backpropagation
        self.cache['dropout_param'] = dropout_param
        self.cache['mask'] = mask

        # Convert "out" type and return output and cache
        out = out.astype(x.dtype, copy=False)
        return out, mask, mode

    def forward(self, input, dropout_param):
        # dropout function
        out, mask, mode = self.dropout_forward(input, dropout_param)

        lin_output = np.dot(out, self.W) + self.b
        self.output = (
            lin_output if self.activation is None
            else self.activation(lin_output)
        )
        self.input = input

        # the goal is to differentiate if the stage of training or testing.
        if mode == 'train':
            return self.output, (mask * self.W.T).T
        elif mode == 'test':
            return self.output, self.W

    def dropout_backward(self, dout):

        # Recover dropout parameters(p, mask,mode) from cache
        dropout_param, mask = self.cache['dropout_param'], self.cache['mask']
        mode = dropout_param['mode']

        dx = None
        # Back propagate (Dropout layer has no parameters just input X)
        if mode == 'train':
            # Just back propagate dout from the neurons that were used during dropout
            # print('dout.shape', dout.shape)
            # print('mask shape', np.atleast_2d(mask).shape)
            # print('mask.T shape', np.atleast_2d(mask).T.shape)

            dx = np.atleast_2d(mask).T * dout
            # print('dx.shape', dx.shape)
        elif mode == 'test':
            dx = dout

        # Return dx
        return dx

    def backward(self, delta, lamdb):
        # Dropout function, obtain the parameter which created in the forward propagation
        dropout_param, mask = self.cache['dropout_param'], self.cache['mask']

        mode = dropout_param['mode']
        if mode == 'train':
            # self.grad_W = np.atleast_2d(mask * self.input).T.dot(np.atleast_2d(delta)) + lamdb * (mask * self.W.T).T / len(self.input) #atleast_2d: transfer data into 2 dimension
            self.grad_W = np.atleast_2d(mask * self.input).T.dot(np.atleast_2d(delta))
        elif mode == 'test':  # actually it will not run this block of code but I don't want to delete....
            self.grad_W = np.atleast_2d(self.input).T.dot(np.atleast_2d(delta)) + lamdb * self.W / len(
                self.input)  # atleast_2d: transfer data into 2 dimension
        self.grad_b = delta

        d = delta.dot(self.W.T)

        delta_ = d * self.activation_deriv(self.input)
        # print('grad_W size', sys.getsizeof(self.grad_W))
        # print('grad_b size=', sys.getsizeof(self.grad_b))
        # print('delta_ size', sys.getsizeof(delta_))
        return delta_

