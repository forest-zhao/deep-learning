import numpy as np
import h5py
import math
import time
import sys
from mlp import *

with h5py.File('../Input/train_128.h5','r') as H:
    data = np.copy(H['data'])

with h5py.File('../Input/train_label.h5','r') as H_l:
    data_label = np.copy(H_l['label'])


with h5py.File('../Input/test_128.h5','r') as H:
    testData = np.copy(H['data'])

# initialize training dataset and testing dataset
data_train = np.zeros([50000, data.shape[1]])
data_train_label = np.zeros(50000)

data_sample = np.zeros([10000, data.shape[1]])
data_sample_label = np.zeros(10000)

# randomly split data into training dataset and testing dataset
i = 0
while i < 60000:
    it = np.random.randint(data.shape[0])

    if i >= 50000:

        data_sample[i-50000] = data[it]
        data_sample_label[i-50000] = data_label[it]
    else:
        data_train[i] = data[it]
        data_train_label[i] = data_label[it]


    i += 1

### Try different MLP models

print('Multi-class deep learning neuron network begin to work')
nn = MLP([128,96,70,10], 'relu')     # auto initialize three class: MLP, HiddenLayer, Activation
#input_data = data
#output_data = data_label

input_data = data_train
output_data = data_train_label
### Try different learning rate and epochs

MSE = nn.fit(input_data, output_data, learning_rate=0.01, epochs=8, lamdb=6, momemtum_rate=0.1,dropout_param={'p':0.95 ,'mode':'train','seed':9},mini_batch_size=1)




output = nn.predict(data_sample)
output_lable=data_sample_label

# If you want to run "test_128.h5", please uncomment No.58 and comment No.54 & No.55
output_test = nn.predict(testData)

#trainning stage, testing
print('predict:',output)
print('answer:',output_lable)
print('loss:%f'%MSE)
print('loss standard:%f'%np.log(10))
m = output == output_lable
correct = np.sum(m==True)
print('accuracy: %.2f%%'%((correct/output_lable.shape)*100))


# save prediction labels of test data to file

f = h5py.File('../Output/Predicted_labels.h5','w')   #创建一个h5文件，文件指针是f
f['label'] = output_test                #将预测标签写入文件的主键label下面
f.close()
