from hiddenlayer import *
import time
import math
class MLP:

    def __init__(self, layers, activation='relu'):

        ### initialize layers
        self.layers = []

        self.params = []
        self.W = []
        self.activation = activation
        self.mini_size = 0

        print('number of layer:', len(layers))
        for i in range(len(layers) - 1):  # equip the layer
            # the first parameter is the number of dimension of data and the second is the number of neurons in a layer
            # in this case, 2 is the dimensional of data, 1 denotes neurons unit.
            self.layers.append(HiddenLayer(layers[i], layers[i + 1], activation='relu', num_layer=i))
            # self.layers.append(HiddenLayer(layers[i+1], layers[i + 2], activation='relu', num_layer=i))
            # self.layers.append(HiddenLayer(layers[i + 2], layers[i + 3], activation='tanh', num_layer=i))
            self.neuron = layers[-1]

    def forward(self, input, dropout_param):
        # l_W = []
        for layer in self.layers:
            output, w = layer.forward(input, dropout_param)
            input = output
            # l_w = np.sum(np.square(w))
            # l_W.append(l_w)
            self.W.append(w)

        return output

    def softmax_predict(self, X):

        exp_scores = np.exp(X - np.max(X))
        return exp_scores / np.sum(exp_scores)

    def loss(self, X, y):
        num_examples = X.shape[0]

        probs = self.softmax_predict(X)

        correct_logprobs = -np.log(probs[y])

        return correct_logprobs

    def diff(self, X, y):
        num_examples = X.shape[0]
        probs = self.softmax_predict(X)
        probs[y] -= 1
        return probs

    def criterion_MSE(self, y, y_hat, lambd):
        activation_deriv = Activation(self.activation).f_deriv
        y = np.int(y)

        regu_start_time = None
        regu_end_time = None
        loss_start_time = None
        loss_end_time = None
        delta_start_time = None
        delta_end_time = None

        # L2 regularization cost
        # regu_start_time = time.time()
        # l_W = []
        # for w in self.W:
        #     l_w = np.sum(np.dot(w,w.T))
        #     print('l_w size = ', l_w)
        #     l_W.append(l_w)
        # regularization_cost = lambd * np.sum(l_W) /len(y_hat)/2
        # regu_end_time = time.time()
        # print('regu duration = ', regu_end_time - regu_start_time)

        # MSE
        loss_start_time = time.time()
        # loss = self.loss(y_hat, y) + regularization_cost
        loss = self.loss(y_hat, y)
        loss_end_time = time.time()
        # print('loss duration = ', loss_end_time - loss_start_time)


        delta_start_time = time.time()
        delta = self.diff(y_hat, y)
        delta_end_time = time.time()
        # print('delta duration = ', delta_end_time - delta_start_time)
        # print('delta', delta)

        # print('loss', sys.getsizeof(loss))
        # print('delta', sys.getsizeof(delta))

        # return loss and delta
        return loss, delta

    def backward(self, delta, lambd):
        for layer in reversed(self.layers):
            delta = layer.backward(delta, lambd)

    def update_mini(self, learning_rate, momemtum_rate):
        for layer in self.layers:
            # print('grad_W', layer.grad_W)
            layer.v_w = momemtum_rate * layer.v_w + learning_rate * layer.grad_W
            layer.v_b = momemtum_rate * layer.v_b + learning_rate * layer.grad_b
            layer.W -= learning_rate * layer.v_w

            layer.b -= learning_rate * layer.v_b


    def random_mini_batches(self, X, y, mini_batch_size=16, seed_m=0):

        np.random.seed(seed_m)  # To make your "random" minibatches the same as ours
        m = X.shape[0]  # number of training examples
        mini_batches = []

        # Step 1: Shuffle (X, Y)
        permutation = list(np.random.permutation(m))
        shuffled_X = X[permutation]
        shuffled_y = y[permutation].reshape(1, m)

        # Step 2: Partition (shuffled_X, shuffled_Y). Minus the end case.
        num_complete_minibatches = math.floor(
            m / mini_batch_size)  # number of mini batches of size mini_batch_size in your partitionning
        for k in range(0, num_complete_minibatches):
            ### START CODE HERE ### (approx. 2 lines)
            mini_batch_X = shuffled_X[k * mini_batch_size: (k + 1) * mini_batch_size]
            mini_batch_y = shuffled_y[:, k * mini_batch_size: (k + 1) * mini_batch_size]
            ### END CODE HERE ###
            mini_batch = (mini_batch_X, mini_batch_y)
            mini_batches.append(mini_batch)

        # Handling the end case (last mini-batch < mini_batch_size)
        if m % mini_batch_size != 0:
            ### START CODE HERE ### (approx. 2 lines)
            mini_batch_X = shuffled_X[num_complete_minibatches * mini_batch_size:]
            mini_batch_y = shuffled_y[:, num_complete_minibatches * mini_batch_size:]
            ### END CODE HERE ###
            mini_batch = (mini_batch_X, mini_batch_y)
            mini_batches.append(mini_batch)

        return mini_batches

    def fit(self, X, y, learning_rate=0.1, epochs=100, lamdb=0.01, momemtum_rate=0.5,
            dropout_param={'p': 0.5, 'mode': 'train', 'seed': 6}, mini_batch_size=64):
        self.mini_size = mini_batch_size
        X = np.array(X)
        y = np.array(y)
        to_return = 0
        seed_m = 10

        for k in range(epochs):
            epoch_start_time = time.time()
            average_loss = 0
            seed_m = seed_m + 1
            minibatches = self.random_mini_batches(X, y, mini_batch_size, seed_m)

            for l in self.layers:
                l.grad_W = 0
                l.grad_b = 0
            mini_count = 1
            for minibatch in minibatches:

                # Select a minibatch
                (minibatch_X, minibatch_y) = minibatch

                # loss = np.zeros(minibatch_X.shape[0])  # X.shape[0] denotes the number of data and x.shape[1] denotes the dimension of data
                loss = 0.0
                # print('minibatch_x', minibatch_X)
                # print('minibatch_y', minibatch_y)
                for it in range(minibatch_X.shape[0]):
                    forward_start_time = None
                    forward_end_time = None
                    backward_start_time = None
                    backward_end_time = None
                    mse_start_time = None
                    mse_end_time = None

                    i = np.random.randint(minibatch_X.shape[0])  # it will iterate all the data in an array

                    # forward pass
                    forward_start_time = time.time()
                    y_hat = self.forward(minibatch_X[i], dropout_param)
                    forward_end_time = time.time()
                    # print('forward duration = ', forward_end_time - forward_start_time)

                    mse_start_time = time.time()
                    loss, delta = self.criterion_MSE(minibatch_y[:, i], y_hat, lamdb)
                    mse_end_time = time.time()
                    # print('mse duration = ', mse_end_time - mse_start_time)
                    # backward pass
                    backward_start_time = time.time()
                    self.backward(delta, lamdb)
                    backward_end_time = time.time()
                    # print('backward duration = ', backward_end_time - backward_start_time)
                    self.update(learning_rate)
                    # print('finish epoch:',k,'batch:', mini_count,'data:',it)

                    average_loss += loss
                # print('loss[',it,']=',loss[it])
                mini_count += 1
                # update

                self.update_mini(learning_rate, momemtum_rate)



                epoch_end_time = time.time()

            print('epochs = ', k, 'loss = ', average_loss / X.shape[0], 'duration = ',
                  epoch_end_time - epoch_start_time)
        to_return = (average_loss) / X.shape[0]

        return to_return

    def update(self, lr):
        for layer in self.layers:
            layer.grad_W += lr * layer.grad_W
            layer.grad_b += lr * layer.grad_b

    def predict(self, x):
        x = np.array(x)
        output = np.zeros(x.shape[0])
        for i in np.arange(x.shape[0]):
            result = self.forward(x[i, :], dropout_param={'p': 0.5, 'mode': 'test', 'seed': 6})
            # print('result', result)
            output[i] = np.argmax(result)
        return output
